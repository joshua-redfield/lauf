#!/bin/sh
########################################################
# Lauf.Calc v0.3.0                                     #
# (c) 2010 joshua.redfield(AT)gmail.com                #
# Dependencies: Zenity, Notify-OSD                     #
########################################################
########################################################
# Functions                                            #
########################################################
_calc() {
   calc=$(echo $(($get_math)))
   notify-send "${lauf_app_name} - Calculator" "${get_math}=${calc}" -i "${lauf_app_icon}"
}
########################################################
# Arguements for skipping GUI                          #
########################################################
if [ ! $2 = "" ]; then
   get_math=$2
   _calc
   return
fi
########################################################
# GUI Code                                             #
########################################################
get_math=$(zenity --entry --width=${lauf_width} --window-icon=${lauf_app_icon} --title="${lauf_app_name}" --text="Enter a simple integer equation below\nTip: You MUST use order of operations.")
case $? in
    0)
        _calc
        return
        ;;
    1)
        exec $0
esac
return
