Table of Contents
-----------------
1. About
2. How to use Lauf
   2a. Core Plugins
   2b. Built-in Plugins
   2c. Common Issues
3. Keyboard shortcut
4. License

1.) About
What is Lauf? Well for one it's the german word for "Run". Also to answer your next question, No. I am NOT german. Lauf is a lightweight application and task launcher that's completely programmed in the SIMPLE bash scripting language. Lauf is the arch-nemesis of the project Alawalk(http://alawalk.tk), The developer who did things we shall not waste your time on.

2.) How to use Lauf?
This all depends on what you intend to do with Lauf. However, In any case typing an application name into Lauf will execute that application. There are a few core plugins that do not require activation. The difference between the core folder and the plugins folder is simple. Plugins in the 'core' folder only depend on what Lauf depends on(See dependencies). Plugins in the folder 'plugins' require some sort of other software that may or may not be installed on your system.

2a. CORE PLUGINS
- help
+ help with <application>
- look
+ look for <file>
+ look in <dir> for <file>
- calc
+ calc <arbitary math>
- plugins
+ plugins + <plugin_name>
+ plugins - <plugin_name>

2b. Built-in plugins:
Run command with output
$ <command>
Run bash style commands
#! <command>

2c. Common Issues
Lauf simply blinks when I type in <blank>
- Either you made a typo, Your plugin isn't activated, Or that application isn't installed.

3.) Keyboard Shortcut
* Head over to System > Preferences > Keyboard Shortcuts.
* Click 'add' and enter 'Lauf' as the name, /dir/you/extracted/to/lauf as it's 'command'
* Click 'OK'.
* Double click on the created keystroke
* Press a Keystroke combination to bind Lauf to
* Click 'Ok'.

4.) License
Lauf - a lightweight application and task launcher
Copyright (C) 2010  Joshua Redfield
This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
You should have received a copy of the GNU General Public License along with this program.  If not, see <http://www.gnu.org/licenses/>.
