#!/bin/sh
########################################################
# Lauf.Decompress v0.2.0                               #
# (c) 2010 joshua.redfield(AT)gmail.com                #
# Dependencies: Zenity, Notify-OSD, tar, zip, unrar    #
########################################################
########################################################
# Arguements for skipping GUI                          #
########################################################
if [ ! $2 = "" ] || [ ! $3 = "" ] || [ ! $4 = ""]; then
   _type=$2
   _file=$3
   _dire=$4
   if [ $2 = "zip" ] || [ $2 = "ZIP" ] || [ $2 = "Zip" ]; then
        cd ${_dire}
        ${_file}
        return
   fi
   if [ $2 = "tar" ] || [ $2 = "TAR" ] || [ $2 = "TAR" ]; then
        tar -zxvf ${_file} -C ${_dire}
        return
   fi
   if [ $2 = "rar" ] || [ $2 = "RAR" ] || [ $2 = "Rar" ]; then
        unrar x ${_file} ${_dire}
        return
   fi
   return
fi
########################################################
# GUI Code                                             #
########################################################
_dialogs() {
    _file=`zenity --file-selection \ 
           --window-icon=${lauf_app_icon} \
           --title=${lauf_app_name}" - $1"`
    _dire=`zenity --file-selection \
           --directory \
           --window-icon=${lauf_app_icon} \
           --title=${lauf_app_name}" - $1"`
     if [ $? = 1 ]; then
        exec $0;
     fi
}
ACTION=`zenity --list $icon --radiolist --text="Which format are we decompressing?" --title="${lauf_app_name} - Decompress" --column "Choice" --column "Format" TRUE "Zip" FALSE "TAR" FALSE "RAR"`
case $? in
0)
    if [ -n "${ACTION}" ]; then
        case $ACTION in
        "Zip")
            _dialogs
            cd ${_dire}
            unzip ${_file}
        ;;
        "TAR")
            _dialogs
            tar -zxvf ${_file} -C ${_dire}
        ;;
        "RAR") 
            _dialogs
            unrar x ${_file} ${_dire}
        ;;
        esac
    fi
;;
1)
    exec $0
;;
esac
