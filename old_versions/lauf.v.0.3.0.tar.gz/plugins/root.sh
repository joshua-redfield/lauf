#!/bin/sh
########################################################
# Lauf.Root v0.1.0                                     #
# (c) 2010 joshua.redfield(AT)gmail.com                #
# Dependencies: Zenity, Notify-OSD, gksudo or gksu     #
########################################################
#_sudo_command=gksu
_sudo_command=gksudo
########################################################
# Arguements for skipping GUI                          #
########################################################
if [ ! $2 = "" ]; then
   _sudo=$2
   ${_sudo_command} ${_sudo}
   return
fi
########################################################
# GUI Code                                             #
########################################################
_sudo=`zenity --entry --width=${lauf_width} --window-icon=$lauf_app_icon --title="${lauf_app_name}" --text="What are we running as root?\nNote: Caution when running things as root!"`
case $? in
    0)
        ${_sudo_command} ${_sudo}
        return;;
    1)
        exec $0;;
esac
