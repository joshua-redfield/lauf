#!/bin/sh
########################################################
# Lauf.xkill v0.2.0                                    #
# (c) 2010 joshua.redfield(AT)gmail.com                #
# Dependencies: Zenity, Notify-OSD, xkill              #
########################################################
if [ ! $2 = "" ]; then
   killall $2
   return
fi
notify-send "${lauf_app_name} - xkill" "Click an application window to kill" -i "${lauf_app_icon}"
exec xkill

