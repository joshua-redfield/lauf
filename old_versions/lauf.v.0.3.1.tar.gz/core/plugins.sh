#!/bin/sh
########################################################
# Lauf.Plugins v0.3.0                                  #
# (c) 2010 joshua.redfield(AT)gmail.com                #
# Dependencies: Zenity, Notify-OSD, Lauf               #
########################################################
########################################################
# Arguements for skipping GUI                          #
# plugins + <plugin>                                   #
# plugins - <plugin>                                   #
########################################################
_plugin="${lauf_plugin_dir}/$3.sh"
if [ $2 = "-" ] && [ ! $3 = "" ]; then
    chmod a-x "${_plugin}"
    return
elif [ $2 = "+" ] && [ ! $3 = "" ]; then
    chmod a+x "${_plugin}"
    return
fi
########################################################
# GUI Code                                             #
########################################################
com1='zenity --title="'${lauf_app_name}' - Plugins" --window-icon='${lauf_app_icon}' --text="Select plugins to activate or deactivate" --height='${lauf_height}' --width='${lauf_width}' --list --separator=" & " --radiolist --column=" " --column="Plugin" --column="Active"'
########################################################
# Get all plugins from the plugin directory            #
########################################################
for app in ${lauf_plugin_dir}/*
do
    if [ -x $app ]; then
       active="Yes"
    else
        active="No"
    fi 
    com2=" \"\" \"$app\" \"$active\""
    com1=$com1$com2
done

test=$(eval "$com1")
########################################################
# Check to see if plugin is activated already or not   #
# If the plugin is, ask to deactivate. Else, Ask to    #
# activate.                                            #
########################################################
case $? in
"0")
if [ -x $test ]; then
    deactivate=$(zenity --question --text "This plugin is active, Would you like to deactivate?")
    if [ $? = 0 ]; then
        chmod a-x $test
        exec $0
    else
        exec $0
    fi
else
    activate=$(zenity --question --text "This plugin is deactive, Would you like to activate?")
    if [ $? = 0 ]; then
    chmod a+x $test
    exec $0
    else
       exec $0
    fi
fi
;;
"1")
exec $0
;;
esac

