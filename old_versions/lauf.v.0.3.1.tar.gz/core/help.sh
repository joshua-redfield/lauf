#!/bin/sh
########################################################
# Lauf.Help v0.2.0                                     #
# (c) 2010 joshua.redfield(AT)gmail.com                #
# Dependencies: Zenity, Notify-OSD, README.TXT         #
########################################################
if [ $2 = "with" ]; then
    manual=$3
    man ${manual} >> "${lauf_app_dir}/.manual"
    wait
    zenity --text-info --width="600" --height=${lauf_height} --window-icon=${lauf_app_icon} --title="${lauf_app_name}" --filename="${lauf_app_dir}/.manual"
    wait
    rm -f "${lauf_app_dir}/.manual"
    return
fi
zenity --text-info --width="600" --height=${lauf_height} --window-icon=${lauf_app_icon} --title="${lauf_app_name}" --filename="${lauf_app_dir}/README.txt"
if [ $? = 0 ]; then
    exec $0
else
    return
fi
