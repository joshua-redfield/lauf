#!/bin/sh
########################################################
# Lauf.Look v0.3.0                                     #
# (c) 2010 joshua.redfield(AT)gmail.com                #
# Dependencies: Zenity, Notify-OSD                     #
########################################################
# Functions                                            #
########################################################
search="unset"
search_dir="unset"
_find() {
        notify-send "${lauf_app_name}" "Looking in ${search_dir} for ${search}" -i "${lauf_app_icon}"
        find -name ${search} | zenity --width=${lauf_width} --height=$(($lauf_height-100)) --window-icon=$lauf_app_icon --list --editable --title  "${lauf_app_name}" --text "Results will appear as they are found\nTip: Click twice to be able to copy" --column "Results"
        if [ $? = "0" ]; then
            return
        else
            exec $0
        fi
}
########################################################
# Arguements for skipping GUI                          #
# look in <dir> for <file>                             #
# look for <file>                                      #
########################################################
if [ $2 = "for" ]; then
    search=$3
    search_dir="filesystem"
    _find
    return
elif [ $2 = "in" ]; then
    search_dir=$3
    search=$5
    cd $search_dir
    _find
    return
fi
########################################################
# GUI Code                                             #
########################################################
search=$(zenity --entry --width=${lauf_width} --window-icon=$lauf_app_icon --title="${lauf_app_name}" --text="What are you looking for?")
case $? in
    0)
        search_dir="filesystem"
        _find
        return
    ;;
    1)
        exec $0
    ;;
    *)
        return
    ;;
esac
