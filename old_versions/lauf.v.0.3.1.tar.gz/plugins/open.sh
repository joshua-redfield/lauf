#!/bin/sh
########################################################
# Lauf.Calc v0.3.0                                     #
# (c) 2010 joshua.redfield(AT)gmail.com                #
# Dependencies: Zenity, Notify-OSD, bc                 #
########################################################
########################################################
# Arguements for skipping GUI                          #
########################################################
if [ ! $2 = "" ]; then
   for arg in $@
   do
        if [ ! $arg = $1 ]; then
            xdg-open $arg
        fi
   done
   return
fi
########################################################
# GUI Code                                             #
########################################################
cd $HOME
arg=$(zenity --file-selection --window-icon=${lauf_app_icon} --title=${lauf_app_name}" - $1")
case $? in
    0)
        xdg-open $arg
        return
        ;;
    1)
        exec $0
esac
return
