Table of Contents
-----------------
1. About
2. Plugins
3. Keyboard shortcut
4. License

1.) About
What is Lauf? Well for one it's the german word for "Run". Also to answer your next question, No. I am NOT german. Lauf is a simple, lightweight, application launcher that's completely programmed in bash. Lauf is the arch-nemesis of the project Alawalk(http://alawalk.tk).

2.) Plugins
Typing "plugins" as a command in Lauf will bring up a list the following plugins you can activate and deactivate. By default all plugins except for "help" and "plugins" are deactivated. 

help - Will show this readme.txt file.
calc <equation> - Order of operations calculator
tweet <message> - Twitter status updater
google <search> - google search
find <file>- searching home directory for a specific file
terminal - Will run an application, then print it's output into Nemesis
xkill - runs xkill for simplicity
decompress <zip,tar,rar> <directory> - Allows you decompress many different types of archives
root <application> - Runs application as root
download <http/ftp url> - Simple wget GUI
gmail - check a gmail account. Must edit gmail.sh and add in your email and password
process kill <application> - Opens a process list that allows you to kill(close) an application
myip - shows your internet ip(What everyone sees you as)
stats - Shows some system and user stats, Pretty basic though

3.) Keyboard Shortcut
* Head over to System > Preferences > Keyboard Shortcuts.
* Click 'add' and enter 'Lauf' as the name, /dir/you/extracted/to/lauf as it's 'command'
* Click 'OK'.
* Double click on the created keystroke
* Press a Keystroke combination to bind Lauf to
* Click 'Ok'.

4.) License
Lauf - a simple application and task launcher
Copyright (C) 2010  Joshua Redfield
This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
You should have received a copy of the GNU General Public License along with this program.  If not, see <http://www.gnu.org/licenses/>.
