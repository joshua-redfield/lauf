#!/bin/sh
########################################################
# Lauf.Calc v0.2.0                                     #
# (c) 2010 joshua.redfield(AT)gmail.com                #
# Dependencies: Zenity, Notify-OSD, bc                 #
########################################################
########################################################
# Functions                                            #
########################################################
_calc() {
   calc=`echo "${get_math}" | bc `
   notify-send "${lauf_app_name} - Calculator" "${get_math}=${calc}" -i "${lauf_app_icon}"
}
########################################################
# Arguements for skipping GUI                          #
########################################################
if [ ! $2 = "" ]; then
   get_math=$2
   _calc
   return
fi
########################################################
# GUI Code                                             #
########################################################
get_math=`zenity --entry --width=${lauf_width} --window-icon=${lauf_app_icon} --title="${lauf_app_name}" --text="You do math? HA!\nNote: Use order of operations dumbass!"`
case $? in
    0)
        _calc
        return
        ;;
    1)
        exec $0
esac
return
