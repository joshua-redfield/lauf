Table of Contents
-----------------
1. About
2. Plugins
3. Keyboard Shortcut
4. License

1.) About
What is Lauf? Well for one it's the german word for "Run". Also to answer your next question, No. I am NOT german. Lauf is a simple, lightweight, application launcher that's completely programmed in bash. Lauf is the arch-nemesis of the project Alawalk(http://alawalk.tk) which did not give credit for some patches they used. Lauf oringally called Nemesis was a set of addons and features that Alawalk at the time did not include. Lauf aims are simple. Do what Alawalk does, Do it better, all while being more lightweight.

2.) Plugins
Typing "plugins" as a command in Lauf will bring up a list the following plugins you can activate and deactivate. By default all plugins except for "help" and "plugins" are deactivated. 

help - Will show this readme.txt file.
calc - Order of operations calculator
tweet - Twitter status updater
google - google search
find - searching home directory for a specific file
terminal - Will run an application, then print it's output into Nemesis
kill - runs xkill for simplicity
decompress - Allows you decompress many different types of archives
root - Runs commands as root
download - Simple wget GUI

3.) Keyboard Shortcut
When assinging Lauf to a keyboard shortcut, Use bind.sh for the bind.
DO NOT attempt to bind nemesis itself as some plugins WILL NOT work.

4.) License
Lauf - a simple application lancher
Copyright (C) 2010  Joshua Redfield

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
