#!/bin/sh
########################################################
# Lauf.Google v0.1.0                                   #
# (c) 2010 joshua.redfield(AT)gmail.com                #
# Dependencies: Zenity, Notify-OSD, gconftool-2        #
########################################################
lauf_plugin_name="Google Search"
default_browser=`gconftool-2 --get '/desktop/gnome/url-handlers/http/command' | cut -f1 -d' ' `
google='http://google.com/#q='
google_search=`zenity --entry --width=${lauf_width} --window-icon=$lauf_app_icon --title="${lauf_app_name}" --text="What are you searching google for?\nNote: You're a dumbass"`
case $? in
    0)
        notify-send "${lauf_app_name} - Google" "Searching for: ${google_search}" -i "${lauf_app_icon}"
        $default_browser $google"${google_search}"
        exit;;
    1)
        exec $0;;
esac
