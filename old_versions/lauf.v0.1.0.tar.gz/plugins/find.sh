#!/bin/sh
########################################################
# Lauf.Find v0.1.0                                     #
# (c) 2010 joshua.redfield(AT)gmail.com                #
# Dependencies: Zenity, Notify-OSD                     #
########################################################
lauf_plugin_name="Find Files"
search=`zenity --entry --width=${lauf_width} --window-icon=$lauf_app_icon --title="${lauf_app_name}" --text="Now what are you looking for?\nNote: only searches inside home directory."`
case $? in
    0)
        cd $HOME
        find -name ${search} >> ${lauf_app_dir}"/find_temp" &
        notify-send "${lauf_app_name} - Find" "Seaching $HOME for ${_search}" -i "${lauf_app_icon}"
        wait
        zenity --text-info --width=${lauf_width} --height=${lauf_height} --window-icon=${lauf_app_icon} --title="${lauf_app_name}" --filename="${lauf_app_dir}/find_temp"
        wait
        rm -f ${lauf_app_dir}"/find_temp"
        exit;;
    1)
        exec $0;;
esac
