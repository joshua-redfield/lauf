#!/bin/sh
########################################################
# Lauf.Help v0.1.0                                     #
# (c) 2010 joshua.redfield(AT)gmail.com                #
# Dependencies: Zenity, Notify-OSD, README.TXT         #
########################################################
zenity --text-info --width=${lauf_width} --height=${lauf_height} --window-icon=${lauf_app_icon} --title="${lauf_app_name}" --filename="${lauf_app_dir}/README.txt"
if [ $? = 0 ]; then
    exec $0
fi
