#!/bin/sh
########################################################
# Lauf.Terminal v0.1.0                                 #
# (c) 2010 joshua.redfield(AT)gmail.com                #
# Dependencies: Zenity, Notify-OSD                     #
########################################################
lauf_plugin_name="Terminal"
_term=`zenity --entry --width=${lauf_width} --window-icon=$lauf_app_icon --title="${lauf_app_name}" --text="Run which command with terminal output?"`
case $? in
    0)
        exec $_term >> ${lauf_app_dir}"/temp_term" &
        notify-send "${lauf_app_name} - Terminal" "Running ${_term} and waiting for it's output" -i "${lauf_app_icon}"
        wait
        zenity --text-info --width=${lauf_width} --height=${lauf_height} --window-icon=${lauf_app_icon} --title="${lauf_app_name}" --filename="${lauf_app_dir}/temp_term"
        wait
        rm -f ${lauf_app_dir}"/temp_term"
        exit
    ;;
    1)
        exec $0
    ;;
esac
