#!/bin/sh
########################################################
# Lauf.xkill v0.1.0                                    #
# (c) 2010 joshua.redfield(AT)gmail.com                #
# Dependencies: Zenity, Notify-OSD, xkill              #
########################################################
notify-send "${lauf_app_name} - xkill" "Click on application window to kill" -i "${lauf_app_icon}"
exec xkill

