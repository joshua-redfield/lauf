#!/bin/sh
########################################################
# Lauf.Calc v0.1.0                                     #
# (c) 2010 joshua.redfield(AT)gmail.com                #
# Dependencies: Zenity, Notify-OSD, bc                 #
########################################################
get_math=`zenity --entry --width=${lauf_width} --window-icon=${lauf_app_icon} --title="${lauf_app_name}" --text="You do math? HA!\nNote: Use order of operations dumbass!"`
case $? in
    0)
        calc=`echo "$get_math" | bc`
        notify-send "${lauf_app_name} - Calculator" "${get_math}=${calc}" -i "${lauf_app_icon}"
        exit;;
    1)
        exec $0
esac
