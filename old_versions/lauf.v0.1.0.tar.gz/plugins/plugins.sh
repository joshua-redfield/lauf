#!/bin/sh
########################################################
# Lauf.Plugins v0.1.0                                  #
# (c) 2010 joshua.redfield(AT)gmail.com                #
# Dependencies: Zenity, Notify-OSD, Lauf               #
########################################################
com1='zenity --title="'${lauf_app_name}' - Plugins" --window-icon='${lauf_app_icon}' --text="Select plugins to activate or deactivate" --height='${lauf_height}' --width='${lauf_width}' --list --separator=" & " --radiolist --column="Select" --column="Plugin Command"'
########################################################
# Get all plugins from the plugin directory            #
########################################################
for app in ${lauf_plugin_dir}/*
do
    com2=" \"\" \"$app\""
    com1=$com1$com2
done

test=`eval "$com1"`
########################################################
# Check to see if plugin is activated already or not   #
# If the plugin is, ask to deactivate. Else, Ask to    #
# activate.                                            #
########################################################
case $? in
"0")
if [ -r $test ]; then
    deactivate=`zenity --question --text "This plugin is active, Would you like to deactivate?"`
    if [ $? = 0 ]; then
        chmod a-r $test
        exec $0
    else
        exec $0
    fi
else
    activate=`zenity --question --text "This plugin is deactive, Would you like to activate?"`
    if [ $? = 0 ]; then
    chmod a+r $test
    exec $0
    exit;
    else
       exec $0
    fi
fi
;;
"1")
exec $0
;;
esac

